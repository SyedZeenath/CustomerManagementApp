import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: '<store></store>',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'cmsApp';
}
