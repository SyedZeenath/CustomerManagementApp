import { NgModule } from "@angular/core";
import { DataSource } from './datasource';
import { Customer } from './customer.model';
import { CustomerRepository } from './customer.repository';



@NgModule({
    imports:[],
    providers:[CustomerRepository,Customer,DataSource]
})

export class ModelModule{ }