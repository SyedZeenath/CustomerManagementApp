import { Injectable } from "@angular/core";


@Injectable()
export class Customer {

    public orders?: object ;
    

    constructor(public id: number,
        public firstName?: string,
        public lastName?: string,
        public address?: string,
        public city?: string
        ) {}
        
}
