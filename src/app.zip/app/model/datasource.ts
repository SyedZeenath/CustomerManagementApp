import { Injectable } from "@angular/core";
import { Observable } from "rxjs/Observable";
import "rxjs/add/observable/from";
import { Customer } from './customer.model';

@Injectable()
export class DataSource{
private customers: Customer[] = [
    {
        id: 1, firstName: 'Lee', lastName: 'Carroll', address: '1234 Anywhere St.', city: 'Phoenix',
        
    },
    {
        id: 2, firstName: 'Lee1', lastName: 'Carroll', address: '1234 Anywhere St.', city: 'NewYork',
        
    }
    
        // new Customer(1, "Syed", "zee", "bangalore"),
        // new Customer(2, "Syed1", "zee1", "bangalore"),
        // new Customer(3, "Syed2", "zee2", "bangalore"),
         
];


getCustomers(): Observable<Customer[]> {

    return Observable.from([this.customers]);
    
}

}
