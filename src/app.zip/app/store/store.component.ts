import { Component } from '@angular/core';
import { Customer } from '../model/customer.model';
import { CustomerRepository } from '../model/customer.repository';
import { Router } from "@angular/router";

@Component({
    selector: "store",
    templateUrl: "store.component.html"
})

export class StoreComponent{
    customer: Customer;

    constructor(private repository: CustomerRepository){ 

this.customer = { id: 0, firstName: "", lastName: "", address: "", city: "", orders: null };

    }



    get customers(): Customer[] {
        return this.repository.getCustomers();
    }
    // get newCustomers(): Customer[]{
    //     return this.repository.getNewCustomers();
    // }

     addCustomer(newCustomer: Customer) {
        return this.repository.addCustomers(newCustomer);
                
    }
    
    deleteCustomer(DelCustomer){
        return this.repository.deleteCustomer(DelCustomer);
    }

    // ordersPage(customers: Customer) {
    //     //this.cart.addLine(product);
    //     this.router.navigateByUrl("/order");
    // }
    
     
}